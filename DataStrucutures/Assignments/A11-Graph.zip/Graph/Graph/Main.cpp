/***********************************************************
* Author:					Lydia Doza
* Date Created:				25/5/2015
* Last Modification Date:	25/5/2015
* Lab Number:				
* Filename:					Graph
*
* Overview:
*	
*
* Input:
*
*
* Output:
*
************************************************************/
#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <crtdbg.h>
#define _CRTDBG_MAP_ALLOC



int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);



	return 0;
}