/******************************************************
*
* Used for coordinates for each cell area.
*
******************************************************/

#ifndef DISPLAY_H
#define DISPLAY_H
#include <Windows.h>
namespace DISPLAY
{
	//coordinates for display
	const COORD FREE_UPPER_LEFT = { 6, 6 };
	const COORD HOME_UPPER_LEFT = { 20, 6 };
	const COORD PLAY_UPPER_LEFT = { 8, 10 };
	
}
#endif