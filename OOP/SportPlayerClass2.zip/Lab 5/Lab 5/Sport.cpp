/******************************************************
*	Author:			Lydia Doza
*	Date created:	1/25/2015
*	Date modified:	2/11/2015
*	Title:			Sport.cpp
******************************************************/
#include "Sport.h"

/**************************************************************
*	Name:
*		Sport()
*
*	Purpose:
*		sets m_array to nullptr and length to zero
*
*	Entry:
*		Nothing.
*
*	Exit:
*		initialized m_array and m_length
****************************************************************/
Sport::Sport() : m_array(nullptr), m_length(0)
{

}

/**************************************************************
*	Name:
*		~Sport()
*
*	Purpose:
*		deallocates m_array and elements of m_array
*
*	Entry:
*		Nothing.
*
*	Exit:
*		Memory is deallocated.
****************************************************************/
Sport::~Sport()
{
	for (int i = 0; i < m_length; i++)
	{
		delete m_array[i];
	}

	delete[] m_array;
}

/**************************************************************
*	Name:
*		DisplayMenu()
*
*	Purpose:
*		Displays menu
*
*	Entry:
*		Nothing.
*
*	Exit:
*		calls prompt user
****************************************************************/
void Sport::DisplayMenu()
{
	system("cls");
	cout << "Oregon Institute of Technology" << endl;
	cout << "\tA - Add a Player"
		<< "\n\tS - Search For / Display a Player"
		<< "\n\tD - Display all Players"
		<< "\n\tR - Remove a Player"
		<< "\n\tE - Exit" << endl;
	cout << "\n\t** Player count: ";
	DisplayCount();
	cout << " **" << endl;
}

/**************************************************************
*	Name:
*		Add()
*
*	Purpose:
*		dynamically creates a new player and adds it to array
*
*	Entry:
*		None.
*
*	Exit:
*		New player is added, array grows by one.
****************************************************************/
void Sport::Add()
{
	Player ** temp = new Player *[m_length + 1];
	char name[64] = { '\0' };
	int grade(0);
	double gpa(0.0);

	for (int i(0); i < m_length; i++)
	{
		temp[i] = m_array[i];
	}

	cout << "What is the new player's name?" << endl;
	cin >> name;

	String to_add(name);

	cout << "What is the player's grade?" << endl;
	cin >> grade;

	cout << "What is the player's gpa?" << endl;
	cin >> gpa;

	temp[m_length] = new Player(to_add, grade, gpa);

	delete[] m_array;

	m_array = temp;

	++m_length;
}

/**************************************************************
*	Name:
*		List()
*
*	Purpose:
*		Displays all players in sport
*
*	Entry:
*		Nothing.
*
*	Exit:
*		All players displayed to screen.
****************************************************************/
void Sport::List()
{
	for (int i(0); i < m_length; i++)
	{
		m_array[i]->Display();
	}
}

/**************************************************************
*	Name:
*		Search()
*
*	Purpose:
*		Searches through players list, if found, prints player
*		info to screen
*
*	Entry:
*		name to compare
*
*	Exit:
*		either nothing or player and it's info
****************************************************************/
void Sport::Search() const
{
	char name[64] = { '\0' };
	bool found = false;
	int flag = 0;

	cout << "Who would you like to find? ";
	cin >> name;

	String s_name(name);

	for (int i(0); i < m_length; i++)
	{
		if (m_array[i]->Search(s_name))
		{
			flag = i;
			found = true;
		}
	}

	if (found)
		m_array[flag]->Display();
	else
		cout << "\nPlayer not found." << endl;
}

/**************************************************************
*	Name:
*		DisplayCount()
*
*	Purpose:
*		returns number of players
*
*	Entry:
*		nothing.
*
*	Exit:
*		number of players printed to screen.
****************************************************************/
void Sport::DisplayCount() const
{
	cout << m_length;
}

/**************************************************************
*	Name:
*		PromptUser()
*
*	Purpose:
*		calls appropriate function given user input
*
*	Entry:
*		user input based on menu in DisplayMenu()
*
*	Exit:
*		method called.
****************************************************************/
void Sport::PromptUser()
{
	char choice = '\0';
	char temp[128] = { '\0' };

	while (choice != 'E')
	{
		DisplayMenu();
		cin.sync();
		cin.getline(temp, 128);
		choice = temp[0];
		choice = toupper(choice);

		if (choice != 'A' && choice != 'S'
			&& choice != 'D' && choice != 'R'
			&& choice != 'E')
		{
			cout << "\nYour choice did not match with the options, "
				<< "please choose from the options." << endl;
			system("pause");
		}
		else
		{
			switch (choice)
			{
			case 'A':
				Add();
				break;

			case 'S':
				Search();
				system("pause");
				break;

			case 'D':
				List();
				system("pause");
				break;

			case 'R':	//remove
				DeletePlayer();
				break;

			case 'E':
				break;

			default:
				cout << "\nYour choice did not match with the options." << endl;
				break;
			}
		}
	}
}

/**************************************************************
*	Name:
*		DeletePlayer()
*
*	Purpose:
*		Searches through players list, if found, prints player
*		info to screen
*
*	Entry:
*		Name to compare.
*
*	Exit:
*		either nothing or the player is deleted and a new array
*		is made without the deleted player.
****************************************************************/
void Sport::DeletePlayer()
{
	Player ** temp = new Player *[m_length]; // new array one smaller than m_array
	char to_del[64] = { '\0' };
	bool found = false;
	int flag = 0;

	cout << "\nWho would you like to delete? (Enter name)" << endl;
	List(); // Display all players.

	cin.sync();
	cin.getline(to_del, 64);

	String name(to_del);

	for (int i(0); i < m_length; i++)
	{
		if (m_array[i]->Search(name))
		{
			flag = i;
			found = true;
		}
	}

	if (found)
	{
		for (int i = 0; i < flag; i++) // from beginning to desired delete name
		{
			temp[i] = m_array[i]; // copy m_array into temp.
		}
		for (int i = flag + 1; i < m_length; i++) // from one after the flag until end
		{
			//temp is one smaller than m_array and we don't want any holes
			temp[i - 1] = m_array[i]; // copy rest of m_array into tmep
		}

		//decrement m_length
		--m_length;

		delete[] m_array;
		m_array = new Player *[m_length + 1];

		//Deep copy
		for (int i = 0; i < m_length; i++)
		{
			m_array[i] = temp[i];
		}

	}
	else
		cout << "\nPlayer not found." << endl;
	
	//deallocate mem from temp no matter whether found or not
	delete[] temp;
}