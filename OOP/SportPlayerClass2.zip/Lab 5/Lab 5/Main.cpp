/***********************************************************
* Author:					Lydia Doza
* Date Created:				1/26/2015
* Last Modification Date:	2/11/2015
* Lab Number:				CST 136 Lab 5
* Filename:					Main.cpp
*
* Overview:
*	This program tests the Player and Sport classes. It 
*	creates new players and uses Sport to manipulate the
*	players.
*
* Input:
*	User input for menu to choose options.
*
* Output:
*	Depends on user input.
*
************************************************************/
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#include <iostream>
using std::cout;
using std::cin;	
using std::endl;

#include "Player.h"
#include "Sport.h"
#include "String.h"

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	
	Sport basketball;
	basketball.PromptUser();

	return 0;
}