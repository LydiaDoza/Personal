/******************************************************
*	Author:			Lydia Doza
*	Date created:	1/25/2015
*	Date modified:	2/11/2015
*	Title:			Player.cpp
******************************************************/
#include "Player.h"	

/**************************************************************
*	Name:
*		Player()
*
*	Purpose:
*		sets m_grade to 13, m_gpa to 4.0, and m_name to null.
*
*	Entry:
*		Nothing.
*
*	Exit:
*		members are initialized.
****************************************************************/
Player::Player() : m_grade(13), m_gpa(4.0), m_name('\0')
{

}

/**************************************************************
*	Name:
*		Player(name, grade, gpa)
*
*	Purpose:
*		creates new player and assigns name to m_name, grade
*		to m_grade, and gpa to m_gpa
*
*	Entry:
*		name, grade, and gpa
*
*	Exit:
*		Player initialized.
****************************************************************/
Player::Player(String name, int grade, double gpa) : m_grade(grade), m_gpa(gpa), m_name(name)
{

}

/**************************************************************
*	Name:
*		Player(const Player & player)
*
*	Purpose:
*		copy ctor, copies player into another player
*
*	Entry:
*		name, grade, and gpa
*
*	Exit:
*		Player copied.
****************************************************************/
Player::Player(const Player & player) : m_name(player.m_name), m_grade(player.m_grade), m_gpa(player.m_gpa)
{

}

/**************************************************************
*	Name:
*		~Player()
*
*	Purpose:
*		deallocates memory from player and reinitializes m_name
*
*	Entry:
*		nothing.
*
*	Exit:
*		memory freed and m_name set to nullptr
****************************************************************/
Player::~Player()
{

}

/**************************************************************
*	Name:
*		Display()
*
*	Purpose:
*		Displays player properties
*
*	Entry
*		Nothing
*
*	Exit:
*		player propteries displayed
****************************************************************/
void Player::Display() const
{
	cout << '\n' << setw(15) << left;
	m_name.Write();
	cout << setw(4) << m_grade
		<< setw(7) << setprecision(3) << m_gpa << "\n" << endl;
}

/**************************************************************
*	Name:
*		Search(name)
*
*	Purpose:
*		checks m_name against name
*
*	Entry:
*		name
*
*	Exit:
*		true or false, true if the same, false if not
****************************************************************/
bool Player::Search(const String name)const
{
	bool check = false;

	if (name == m_name) // If the strcmp returns a zero, then true
		check = true;

	return check;
}
/***************************************************************
*	Name:
*		operator =(const Player & player)
*
*	Purpose:
*		Sets *this to same parameters of passed in player
*
*	Entry:
*		none
*
*	Exit:
*		none
*
****************************************************************/
Player& Player::operator = (const Player & player)
{
	if (this != &player)
	{
		m_name = player.m_name;
		m_grade = player.m_grade;
		m_gpa = player.m_gpa;
	}

	return *this;
}

/***************************************************************
*	Name:
*		SetName(String name)
*
*	Purpose:
*		sets m_name to name
*
*	Entry:
*		none
*
*	Exit:
*		none
*
****************************************************************/
void Player::SetName(String name)
{
	m_name = name;
}

/***************************************************************
*	Name:
*		GetName()
*
*	Purpose:
*		Returns m_name
*
*	Entry:
*		none
*
*	Exit:
*		none
*
****************************************************************/
String Player::GetName() const
{
	return m_name;
}

/***************************************************************
*	Name:
*		SetGrade(int grade)
*
*	Purpose:
*		Sets m_grade to grade
*
*	Entry:
*		none
*
*	Exit:
*		none
*
****************************************************************/
void Player::SetGrade(int grade)
{
	m_grade = grade;
}

/***************************************************************
*	Name:
*		GetGrade()
*
*	Purpose:
*		Returns m_grade
*
*	Entry:
*		none
*
*	Exit:
*		none
*
****************************************************************/
int Player::GetGrade() const
{
	return m_grade;
}

/***************************************************************
*	Name:
*		SetGPA(double gpa)
*
*	Purpose:
*		Sets m_gpa to gpa
*
*	Entry:
*		none
*
*	Exit:
*		none
*
****************************************************************/
void Player::SetGPA(double gpa)
{
	m_gpa = gpa;
}

/***************************************************************
*	Name:
*		GetGPA()
*
*	Purpose:
*		Returns m_gpa
*
*	Entry:
*		none
*
*	Exit:
*		none
*
****************************************************************/
double Player::GetGPA() const
{
	return m_gpa;
}