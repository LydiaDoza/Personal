/************************************************************************
* Class: Player
*
* Constructors:
*	Player()
*		Creates and sets month, day, year to 10/1/2014
*
* Destructors:
*	~Player()
*		Deallocates m_month, m_day, m_year
*
* Public Methods:
*	void Set( int month, int day, int year )
*		Sets date to user input. If no input, date is set to 10/1/2014
*	void Increment()
*		Increments day (month and year if necessary)
*	void Display()
*		Display date as MM/DD/YYYY format.
*	void SetName(String name);
*		Sets m_name to name
*
*	String GetName() const;
*		Returns m_name
*
*	void SetGrade(int grade);
*		Sets m_grade to grade
*
*	int GetGrade() const;
*		returns m_grade
*
*	void SetGPA(double gpa);
*		Sets m_gpa to gpa
*
*	double GetGPA() const;
*		Returns GPA
*************************************************************************/
#ifndef PLAYER_H
#define PLAYER_H
#include "String.h"

#include <iostream>
using std::cout;
using std::cin;
using std::endl;

#include <iomanip>
using std::setw;
using std::setprecision;
using std::fixed;
using std::left;

class Player
{
public:
	Player();
	Player(String name, int grade, double gpa);
	Player(const Player & player);
	~Player();
	bool Search(const String) const;
	void Display() const;

	Player& operator = (const Player & player);

	void SetName(String name);
	String GetName() const;

	void SetGrade(int grade);
	int GetGrade() const;

	void SetGPA(double gpa);
	double GetGPA() const;

private:
	String m_name;
	int m_grade;
	double m_gpa;
};
#endif