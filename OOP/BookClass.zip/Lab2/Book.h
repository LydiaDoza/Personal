/************************************************************************
* Class: Book
*
* Constructors:
*	Book()
*		Creates an array for ISBN, Author's last name. Sets date, cost, 
*		quantity, and total cost to zero.
*	Book( char * isbn, char * authorLast, int date, float cost, 
*			int quantity )
*		Creates an array of m_isbn with values in isbn, m_author's name
*		with values in isbn, m_date with value of date, m_cost with 
*		value of cost, and m_quantity with value of quantity. It also
*		sets m_total_value to quantity * cost.
*
* Destructors:
*	~Book()
*		Deallocates m_array
*
*	Public Methods:
*		void DisplayTotalValue()
*			Displays m_total_value
*		void AddBook()
*			Adds user defined amount to quantity
*		void DeleteBook()
*			Subtracts user defined amount from quantity
*		void ChangeCost()
*			Changes cost based on user input
*		float FindValue()
*			Returns m_total_value
*
*	Manipulators:
*		void setISBN(char * isbn)
*			Sets m_isbn to isbn
*		char * getISBN()
*			Returns m_isbn
*		void setAUTHORLAST(char * authorLast)
*			Sets m_authorLast to authorLast
*		char * getAUTHORLAST()
*			Returns m_authorLast
*		void setDATE(int date)
*			Sets m_date to date
*		int getDATE()
*			Returns m_Date
*		void setCOST(float cost)
*			Sets m_cost to cost
*		float getCOST()
*			Returns m_cost
*		void setQUANTITY(int quantity)
*			Sets m_quantity to quantity
*		int getQUANTITY()
*			Returns m_quantity
*************************************************************************/
#ifndef BOOK_H
#define BOOK_H


class Book	//class declaration
{
private:
	char m_isbn[16];
	char m_authorLast[25];
	int m_date;
	float m_cost;
	int m_quantity;
	float m_total_value;
	const int ISBN_SIZE;
	const int AUTHOR_SIZE;

public:
	Book();
	Book(char * isbn, char * authorLast, int date, float cost, int quantity);
	~Book();

	void setISBN(char * isbn);
	char * getISBN();

	void setAUTHORLAST(char * authorLast);
	char * getAUTHORLAST();

	void setDATE(int date);
	int getDATE();

	void setCOST(float cost);
	float getCOST();

	void setQUANTITY(int quantity);
	int getQUANTITY();


	void DisplayTotalValue();
	void AddBook();
	void DeleteBook();
	void ChangeCost();
	float FindValue();

};
#endif