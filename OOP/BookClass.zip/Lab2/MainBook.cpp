/***********************************************************
* Author:					Lydia Doza
* Date Created:				1/19/2015
* Last Modification Date:	1/20/2015
* Lab Number:				CST 136 Lab 2
* Filename:					MainBook.cpp
*
* Overview:
*	This program calls the book class to create three
*	book objects. It will also test the book class methods
*	in a variety of combinations.
*
* Input:
*	No input from user unless it is asked during the method
*	call.
*
* Output:
*	The output of the given methods are printed to the screen
*	
************************************************************/
#include <iostream>
using std::cout;
using std::cin;
using std::endl;

#include "Book.h"

int main()
{
	Book first("0-13-917709-4", "Cleaver", 2007, 74.50, 3);
	Book second("0-314-20039-8", "Fife", 1994, 16.75, 4);
	Book third("0-12-3456671-7", "Zappa", 2012, 21.50, 14);
	Book fourth;
	int first_quant = first.getQUANTITY();
	float sec_cost = second.getCOST();
	float gar = second.FindValue();
	int third_quant = third.getQUANTITY();


	cout << "For the first book";
	first.DisplayTotalValue();

	cout << "For the second book";
	second.DisplayTotalValue();

	cout << "For the third book";
	third.DisplayTotalValue();

	system("pause");
	system("cls");

	cout << "The first book has " << first_quant
		<< " books.";
	first.AddBook();

	cout << "The second book costs $" << sec_cost;
	second.ChangeCost();

	cout << "The third book has " << third_quant
		<< " books.";
	third.DeleteBook();

	first.DisplayTotalValue();

	cout << "\nThe second book has a total of $"
		<< gar << " in stock";

	fourth.setISBN("stuff");
	third.setISBN("stuff");

	cout << "The ISBN for the fourth book is ";
	char * fourth_isbn = fourth.getISBN();
	cout << fourth_isbn;
	return 0;
}