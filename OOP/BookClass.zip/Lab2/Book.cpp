/******************************************************
*	Author:			Lydia Doza
*	Date created:	1/19/2015
*	Date modified:	1/20/2015
*	Title:			Book.cpp
******************************************************/
#include <iostream>
#include "Book.h"
using std::cout;
using std::cin;
using std::endl;

/**************************************************************
*	Name:
*		Book(isbn, authorLast, date, cost, quantity)
*
*	Purpose:
*		Initializes values of Book class
*
*	Entry:
*		All objects in book class
*
*	Exit:
*		All objects in book class changed to 0, m_isbn set to
*		isbn, m_authorLast set to authorLast, m_date set to date,
*		m_cost set to cost, m_quantity set to quantity,
*		m_total_value set to quantity * cost.
****************************************************************/
Book::Book(char * isbn, char * authorLast, int date, float cost, int quantity)
	: m_date(date), m_cost(cost), m_quantity(quantity), m_total_value(quantity*cost), ISBN_SIZE(strlen(m_isbn)), AUTHOR_SIZE(strlen(m_authorLast))
{
	strcpy_s(m_isbn, isbn);
	strcpy_s(m_authorLast, authorLast);
}

/**************************************************************
*	Name:
*		Book()
*
*	Purpose:
*		Overwritten default constructor. Sets everything to
*		zero
*
*	Entry:
*		Nothing.
*
*	Exit:
*		All objects in book class changed to 0,
****************************************************************/
Book::Book() : m_cost(0), m_quantity(0), m_total_value(0), m_date(0), ISBN_SIZE(strlen(m_isbn)), AUTHOR_SIZE(strlen(m_authorLast))
{
	for (int i = 0; i < ISBN_SIZE; i++)
		m_isbn[i] = '/0';

	for (int i = 0; i < AUTHOR_SIZE; i++)
		m_authorLast[i] = '/0';


}

/**************************************************************
*	Name:
*		~Book()
*
*	Purpose:
*		Everything is reset
*
*	Entry:
*		Nothing.
*
*	Exit:
*		All objects in book class reset
****************************************************************/
Book::~Book()
{
}

/**************************************************************
*	Name:
*		DisplayTotalValue(total_value)
*
*	Purpose:
*		Outputs total value for a given book.
*
*	Entry:
*		total_value object
*
*	Exit:
*		total_value is printed to the console window
****************************************************************/
void Book::DisplayTotalValue()
{
	cout << "\nThe total value is: $" << m_total_value << '\n' << endl;
}

/**************************************************************
*	Name:
*		AddBook(quantity)
*
*	Purpose:
*		Add a book to quantity object
*
*	Entry:
*		quantity object and input from the user to indicate
*		how many books to add to current quantity.
*
*	Exit:
*		User indicated amount of books is added to the quantity.
*		Replaces the old quantity value.
****************************************************************/
void Book::AddBook()
{
	int to_add(0);
	cout << "\nHow many books would you like to add? ";
	cin >> to_add;

	if (to_add < 0)
		cout << "\nYou cannot have add a negative number of books.";
	else
		m_quantity += to_add;
}

/**************************************************************
*	Name:
*		DeleteBook(quantity)
*
*	Purpose:
*		Deletes books from total quantity.
*
*	Entry:
*		quantity object and input from the user to indicate
*		how many books to subtract from current quantity
*
*	Exit:
*		user indicated amount of books is subtracted from the
*		total quantity of books. Old quantity value changed.
****************************************************************/
void Book::DeleteBook()
{
	int toSub(0);
	cout << "\nHow many books would you like to delete? ";
	cin >> toSub;

	if (toSub > m_quantity)
		cout << "\nYou cannot subtract more books than you have." << endl;
	else
		m_quantity -= toSub;
}

/**************************************************************
*	Name:
*		ChangeCost(cost)
*
*	Purpose:
*		Changes the cost of a book.
*
*	Entry:
*		User inputs new cost.
*
*	Exit:
*		Cost changed to user indicated amount.
****************************************************************/
void Book::ChangeCost()
{
	float newCost(0.0F);
	cout << "\nWhat would you like to change the cost to? ";
	cin >> newCost;

	if (newCost < 0)
		cout << "\nYou cannot have a negative price." << endl;
	else
		m_cost = newCost;
}

/**************************************************************
*	Name:
*		FindValue(total_value)
*
*	Purpose:
*		Returns total value of a book in stock.
*
*	Entry:
*		Total value of books in stock.
*
*	Exit:
*		Total value is printed to the console window.
****************************************************************/
float Book::FindValue()
{
	return m_total_value;
}

/**************************************************************
*	Name:
*		setISBN(isbn)
*
*	Purpose:
*		Sets member ISBN of book to ISBN of book.
*
*	Entry:
*		ISBN of book.
*
*	Exit:
*		Member ISBN of book set to ISBN of book.
****************************************************************/
void Book::setISBN(char * isbn)
{
	strcpy_s(m_isbn, isbn);
}

/**************************************************************
*	Name:
*		getISBN()
*
*	Purpose:
*		Returns member ISBN of book.
*
*	Entry:
*		None.
*
*	Exit:
*		Member ISBN.
****************************************************************/
char * Book::getISBN()
{
	return m_isbn;
}

/**************************************************************
*	Name:
*		setAUTHORLAST(authorLast)
*
*	Purpose:
*		Sets member author last name to author last name.
*
*	Entry:
*		authorLast
*
*	Exit:
*		Member author's last name is set to author last name.
****************************************************************/
void Book::setAUTHORLAST(char * authorLast)
{
	strcpy_s(m_authorLast, authorLast);
}

/**************************************************************
*	Name:
*		getAUTHORLAST()
*
*	Purpose:
*		Returns member author's last name.
*
*	Entry:
*		None.
*
*	Exit:
*		Member author's last name.
****************************************************************/
char * Book::getAUTHORLAST()
{
	return m_authorLast;
}

/**************************************************************
*	Name:
*		setDate(date)
*
*	Purpose:
*		Sets member date (year) published to date published..
*
*	Entry:
*		date
*
*	Exit:
*		Member date published set to date published.
****************************************************************/
void Book::setDATE(int date)
{
	m_date = date;
}

/**************************************************************
*	Name:
*		getDate()
*
*	Purpose:
*		Returns member date published.
*
*	Entry:
*		None.
*
*	Exit:
*		Member date published is returned.
****************************************************************/
int Book::getDATE()
{
	return m_date;
}

/**************************************************************
*	Name:
*		setCOST(cost)
*
*	Purpose:
*		Sets member cost of book to cost of book.
*
*	Entry:
*		cost.
*
*	Exit:
*		Member cost of book is set to cost of book.
****************************************************************/
void Book::setCOST(float cost)
{
	m_cost = cost;
}

/**************************************************************
*	Name:
*		getCOST()
*
*	Purpose:
*		Returns member cost of book.
*
*	Entry:
*		None.
*
*	Exit:
*		Member cost of book is returned.
****************************************************************/
float Book::getCOST()
{
	return m_cost;
}

/**************************************************************
*	Name:
*		setQUANTITY(quantity)
*
*	Purpose:
*		Sets member quanatity of books to quantity of books.
*
*	Entry:
*		Quantity.
*
*	Exit:
*		Member quantity of books is set to quantity of boks.
****************************************************************/
void Book::setQUANTITY(int quantity)
{
	m_quantity = quantity;
}

/**************************************************************
*	Name:
*		getQUANTITY()
*
*	Purpose:
*		Returns member quantity of books.
*
*	Entry:
*		None.
*
*	Exit:
*		Member quantity of books.
****************************************************************/
int Book::getQUANTITY()
{
	return m_quantity;
}