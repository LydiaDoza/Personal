// YOU NEED TO DO SOME FIXING UP HERE!  Nothing major but just for fun!

#include "myString.h"

// Don't forget you will need to edit/change this to make it look
// like our lab sheet for this week!
int main()
{
   String s1("Test String1");
   String s2("Test String 2");
   String s3(s1);
   s1.Display("HELP");
   s2.Display();
   s3.Display();
      
// Helping you out here :-)  DON'T FORGET TO ADD THE REST FROM THE LAB AND REMOVE THESE //

// if(!s3)
// cout << "s3 is null\n";
// s1 = "";
//if(!s1)
// cout << "s1 is null\n;
   return 0;
}

