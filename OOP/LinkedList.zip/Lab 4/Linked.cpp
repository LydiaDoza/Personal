#include "Node.h"
#include "Player.h"
#include "Sport.h"
#include "String.h"
#include "Linked.h"

#include <iostream>
using std::cout;
using std::cin;
using std::endl;

/***************************************************************
*	Name:
*		Linked()
*
*	Purpose:
*		m_head and m_num_nodes are set to nullptr and zero
*
*	Entry:
*		nothing
*
*	Exit:
*		Linked instance created
****************************************************************/
Linked::Linked() : m_head(nullptr), m_num_nodes(0)
{
}

/***************************************************************
*	Name:
*		~Linked()
*
*	Purpose:
*		m_head and m_num_nodes are set to default null and zero
*
*	Entry:
*		nothing
*
*	Exit:
*		memory deallocated
****************************************************************/
Linked::~Linked()
{
	Node * travel = m_head;
	Node * trail = travel;

	while (travel != nullptr)
	{
		travel = travel->GetNext();
		delete trail;
		trail = travel;
	}

	m_head = nullptr;
	m_num_nodes = 0;
}

/***************************************************************
*	Name:
*		Add()
*
*	Purpose:
*		Creates new node to add to an ordered (by grade)
*		Linked list.
*
*	Entry:
*		None.
*
*	Exit:
*		New node created and added list.
****************************************************************/
void Linked::Add()
{
	char temp[32];
	int grade(0);
	double gpa(0.0);

	Node * travel = m_head;
	Node * trail = nullptr;

	Node * new_node = new Node;

	//Get input from user to create a player
	cout << "\nWhat is the player's name? ";
	cin.getline(temp, 32);

	cout << "\nWhat is the player's grade (fresh = 13, soph = 14, etc.)? ";
	cin >> grade;

	cout << "\nWhat is the player's gpa (on a 4.0 scale)? ";
	cin >> gpa;


	String name(temp);

	new_node->SetPlayer(name, grade, gpa);

	//list is empty
	if (m_head == nullptr)
	{
		m_head = new_node;
		new_node->SetNext(nullptr);
	}

	//inset node befor head
	else if (new_node->GetPlayer().GetGrade() <= m_head->GetPlayer().GetGrade())
	{
		new_node->SetNext(m_head);
		m_head = new_node;
	}

	else
	{
		//while within the list and travel pointer grade is less than new node's grade
		while (travel != nullptr && travel->GetPlayer().GetGrade() < new_node->GetPlayer().GetGrade())
		{
			trail = travel;
			travel = travel->GetNext();
		}

	//set new node between travel and trail
		//set trail's next to new node
		trail->SetNext(new_node);

		//new node's next is set to travel
		new_node->SetNext(travel);
	}
	++m_num_nodes;
}

/***************************************************************
*	Name:
*		DisplayNodes()
*
*	Purpose:
*		Lists all nodes in Linked list.
*
*	Entry:
*		None.
*
*	Exit:
*		None.
****************************************************************/
void Linked::DisplayNodes() const
{
	Node * travel = m_head;

	while (travel != 0)
	{
		// display this node.
		travel->GetPlayer().Display();

		//get next node
		travel = travel->GetNext();
	}
}

/***************************************************************
*	Name:
*		Search(String name)
*
*	Purpose:
*		Finds and returns node data based on name
*
*	Entry:
*		None.
*
*	Exit:
*		Number of nodes is returned.
****************************************************************/
Node * Linked::Search(String name) const
{
	bool found = false;
	Player play;
	Node * travel = m_head;

	if (travel != nullptr)
	{			//not found and still in list
		while (!found && travel != nullptr)
		{
			//travel name does not equal input name
			if (travel->GetPlayer().GetName() != name)
			{
				//set travel to next
				travel = travel->GetNext();
			}

			//travel _does_ equal input name
			else
			{
				//player equals travel player
				play = travel->GetPlayer();
				found = true;
			}
		}
	}
	return travel;
}

/***************************************************************
*	Name:
*		Delete()
*
*	Purpose:
*		Finds and deletes node if found, if not found, error
*		message is displayed
*
*	Entry:
*		None.
*
*	Exit:
*		Number of nodes is returned.
****************************************************************/
void Linked::Delete(String name)
{
	Node * travel = m_head;
	Node * trail = nullptr;

	//list is empty
	if (travel == nullptr)
	{
		cout << "\nPlayer not found." << endl;
	}

	//head is same as name
	else if (travel->GetPlayer().GetName() == name)
	{
		trail = travel;
		travel = travel->GetNext();
		delete trail;
		--m_num_nodes;
	}

	//start going through the list.
	else
	{
		//not end of list and current player's name is not same as delete name
		while (travel != nullptr && travel->GetPlayer().GetName() != name)
		{
			trail = travel;
			travel = travel->GetNext();
		}

		// if made it through the list
		if (travel == nullptr)
		{
			cout << "\nPlayer not found." << endl;
		}
		//player found
		else
		{
			trail->SetNext(travel->GetNext());
			delete travel;
			--m_num_nodes;
		}
	}

}

/***************************************************************
*	Name:
*		GetNumNodes()
*
*	Purpose:
*		Returns number of nodes in list.
*
*	Entry:
*		None.
*
*	Exit:
*		Number of nodes is returned.
****************************************************************/
int Linked::GetNumNodes() const
{
	return m_num_nodes;
}