/************************************************************************
* Class: LinkedList
*
* Constructors:
*	LinkedList()
*
* Destructors:
*	~LinkedList()
*		Deallocates memory from node and player
*
* Public Methods:
*	void Add()
*		Adds a new node to linked list ordered by grade
*
*	void DisplayNodes() const
*		Displays all nodes in linked list
*
*	Node * Search(String name) const
*		Searches all nodes for desired player name, returns a pointer to
*		that node
*
*	void Delete(String name)
*		deletes node from linked list.
*
*	int GetNumNodes() const
*		returns m_num_nodes
*************************************************************************/
#ifndef LINKED_H
#define LINKED_H
#include "Node.h"
#include "Player.h"
class Linked
{
public:
	Linked();
	~Linked();

	void Add();
	void DisplayNodes() const;
	Node * Search(String name) const;
	void Delete(String name);
	int GetNumNodes() const;

private:
	Node * m_head;
	int m_num_nodes;
};

#endif