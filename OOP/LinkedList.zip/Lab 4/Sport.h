/************************************************************************
* Class: Sport
*
* Constructors:
*	Sport()
*		Creates and a sport and sets length and array to zero and
*		nullptr respectively.
*
* Destructors:
*	~Sport()
*		Deallocates memory from array and sport
*
* Public Methods:
*	void DisplayMenu()
*		Displays menu options to console window and displays number
*		of players in linked
*
*	void Add()
*		Calls Player ctor and adds pointer to player to array
*
*	void List() const
*		Displays Players in array and attributes to screen
*
*	void Search() const
*		Prompts user for a name, checks name against the names of
*		existing players in array
*
*	void PromptUser()
*		receives user input from displaymenu()
*************************************************************************/
#ifndef SPORT_H
#define SPORT_H

#include "Linked.h"
class Sport

{
public:
	Sport();
	~Sport();

	void Add();
	void List() const;
	void DeletePlayer();
	void Search() const;
	void PromptUser();

private:
	void DisplayMenu();

	Linked list;
	int m_length;
};

#endif