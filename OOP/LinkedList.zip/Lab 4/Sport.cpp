/******************************************************
*	Author:			Lydia Doza
*	Date created:	1/25/2015
*	Date modified:	2/10/2015
*	Title:			Sport.cpp
******************************************************/
#include "Player.h"
#include "Sport.h"
#include "Linked.h"
#include "Node.h"

#include <iostream>
using std::cout;
using std::cin;
using std::endl;


/**************************************************************
*	Name:
*		Sport()
*
*	Purpose:
*		sets m_array to nullptr and length to zero
*
*	Entry:
*		Nothing.
*
*	Exit:
*		initialized m_array and m_length
****************************************************************/
Sport::Sport() :m_length(0), list()
{

}

/**************************************************************
*	Name:
*		~Sport()
*
*	Purpose:
*		deallocates m_array and elements of m_array
*
*	Entry:
*		Nothing.
*
*	Exit:
*		Memory is deallocated.
****************************************************************/
Sport::~Sport()
{

}

/**************************************************************
*	Name:
*		DisplayMenu()
*
*	Purpose:
*		Displays menu
*
*	Entry:
*		Nothing.
*
*	Exit:
*		calls prompt user
****************************************************************/
void Sport::DisplayMenu()
{
	system("cls");
	cout << "Oregon Institute of Technology" << endl;
	cout << "\tA - Add a Player"
		<< "\n\tS - Search For / Display a Player"
		<< "\n\tD - Display all Players"
		<< "\n\tR - Remove Player"
		<< "\n\tE - Exit" << endl
		<< '\n' << "** Total Current Players: " << list.GetNumNodes() << "**"
		<<"\n\nWhat would you like to do? ";
}

/**************************************************************
*	Name:
*		Add()
*
*	Purpose:
*		dynamically creates a new player and adds it to array
*
*	Entry:
*		None.
*
*	Exit:
*		New player is added, array grows by one.
****************************************************************/
void Sport::Add()
{
	list.Add();
}

/**************************************************************
*	Name:
*		List()
*
*	Purpose:
*		Displays all players in sport
*
*	Entry:
*		Nothing.
*
*	Exit:
*		All players displayed to screen.
****************************************************************/
void Sport::List() const
{
	list.DisplayNodes();
	system("pause");
}

/**************************************************************
*	Name:
*		Delete()
*
*	Purpose:
*		Searches through players list, if found, prints player
*		info to screen
*
*	Entry:
*		name to compare
*
*	Exit:
*		either nothing or player and it's info
****************************************************************/
void Sport::DeletePlayer()
{
	char temp[32] = { '\0' };

	List();
	cout << "\nWho would you like to delete? ";
	cin.sync();
	cin.getline(temp, 32);

	String to_delete(temp);

	list.Delete(to_delete);
	
}

/**************************************************************
*	Name:
*		Search()
*
*	Purpose:
*		Searches through players list, if found, prints player
*		info to screen
*
*	Entry:
*		name to compare
*
*	Exit:
*		either nothing or player and it's info
****************************************************************/
void Sport::Search() const
{
	char temp[64] = { '\0' };
	Player play;
	Node * temp1;

	cout << "Who would you like to find? ";
	cin.sync();
	cin.getline(temp, 64);

	String name(temp);

	play.SetName(name);

	temp1 = list.Search(name);

	if (play.GetName() != nullptr)
	{
		play.Display();
		system("pause");
	}
	
}

/**************************************************************
*	Name:
*		PromptUser()
*
*	Purpose:
*		calls appropriate function given user input
*
*	Entry:
*		user input based on menu in DisplayMenu()
*
*	Exit:
*		method called.
****************************************************************/
void Sport::PromptUser()
{
	char choice = '\0';
	char temp[128] = { '\0' };

	while (choice != 'E')
	{
		DisplayMenu();
		cin.sync();
		cin.getline(temp, 128);
		choice = temp[0];
		choice = toupper(choice);

		if (choice != 'A' && choice != 'S'
			&& choice != 'D' && choice != 'R'
			&& choice != 'E')
		{
			cout << "\nYour choice did not match with the options, "
				<< "please choose from the options." << endl;
			system("pause");
		}
		else
		{
			switch (choice)
			{
			case 'A':
				Add();
				break;

			case 'S':
				Search();
				break;

			case 'D':
				List();
				break;

			case 'R':
				DeletePlayer();
				break;

			case 'E':
				break;

			default:
				cout << "\nYour choice did not match with the options." << endl;
				system("pause");
				break;
			}

		}
	}

}