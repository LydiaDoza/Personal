/************************************************************************
* Class: Player
*
* Constructors:
*	Player()
*		Creates and m_name to \0, grade to 13, and gpa to 4.0
*
*	Player( name, grade, gpa )
*		three arg ctor, sets m_name to name, m_grade to grade, and m_gpa
*		to gpa
*
*	Player( const Player & player )
*		copy ctor, copys player to this player
*
* Destructor:
*	~Player()
*		Deallocates m_month, m_day, m_year
*
* Public Methods:
*		void SetName(String name);
*			Sets m_name to name
*
*		String GetName() const;
*			Returns m_name
*
*		void SetGrade(int grade);
*			Sets m_grade to grade
*
*		int GetGrade() const;
*			returns m_grade
*
*		void SetGPA(double gpa);
*			Sets m_gpa to gpa
*
*		double GetGPA() const;
*			Returns GPA
*
*		bool Search(const String&) const;
*			Searchs for String Name, 1 true, 0 false
*
*		void Display() const;
*			Displays all player info
*	
*		Player& operator = (const Player & player);	
*			sets this m_player is set to player.
*************************************************************************/
#ifndef PLAYER_H
#define PLAYER_H
#include "String.h"
class Player
{
public:
	Player();
	Player(String name, int grade, double gpa);
	~Player();
	Player(const Player & player);

	void SetName(String name);
	String GetName() const;

	void SetGrade(int grade);
	int GetGrade() const;

	void SetGPA(double gpa);
	double GetGPA() const;

	bool Search(const String&) const;
	void Display() const;

	Player& operator = (const Player & player);

private:
	String m_name;
	int m_grade;
	double m_gpa;
};

#endif