#include "Node.h"
#include "Player.h"
#include "Sport.h"
#include "String.h"

/***************************************************************
*	Name:
*		Node()
*
*	Purpose:
*		m_next set to null ptr and m_player set to null,0,0
*
*	Entry:
*		None.
*
*	Exit:
*		None.
****************************************************************/
Node::Node() : m_next(nullptr), m_player('\0', 0, 0)
{

}

/***************************************************************
*	Name:
*		Search(Player player)
*
*	Purpose:
*		m_next set to null ptr and m_player set to input player
*
*	Entry:
*		name
*
*	Exit:
*		true or false, true if the same, false if not
****************************************************************/
Node::Node(Player player) : m_next(nullptr), m_player(player)
{

}

/***************************************************************
*	Name:
*		~Node()
*
*	Purpose:
*		m_next set to nullptr and m_player reset to null,0,0
*
*	Entry:
*		name
*
*	Exit:
*		true or false, true if the same, false if not
****************************************************************/
Node::~Node()
{
	//m_next = nullptr;
}

/***************************************************************
*	Name:
*		SetNext(Node * next)
*
*	Purpose:
*		Sets m_next to input next.
*
*	Entry:
*		Node pointer
*
*	Exit:
*		m_next is set.
****************************************************************/
void Node::SetNext(Node * next)
{
	m_next = next;
}

/***************************************************************
*	Name:
*		GetNext()
*
*	Purpose:
*		Returns next pointer
*
*	Entry:
*		None.
*
*	Exit:
*		next pointer returned.
****************************************************************/
Node * Node::GetNext()
{
	return m_next;
}

/***************************************************************
*	Name:
*		SetPlayer(Player player)
*
*	Purpose:
*		m_player is set to player
*
*	Entry:
*		None.
*
*	Exit:
*		None.
****************************************************************/
void Node::SetPlayer(Player player)
{
	m_player = player;
}

/***************************************************************
*	Name:
*		SetPlayer(String name, int grade, double gpa)
*
*	Purpose:
*		Player in Node is set to name, grade, and gpa.
*
*	Entry:
*		None.
*
*	Exit:
*		None.
****************************************************************/
void Node::SetPlayer(String name, int grade, double gpa)
{
	m_player.SetName(name);
	m_player.SetGrade(grade);
	m_player.SetGPA(gpa);

}

/***************************************************************
*	Name:
*		GetPlayer()
*
*	Purpose:
*		Returns m_player info
*
*	Entry:
*		None.
*
*	Exit:
*		m_player
****************************************************************/
Player Node::GetPlayer() const
{
	return m_player;
}

/***************************************************************
*	Name:
*		operator = (const Node& node)
*
*	Purpose:
*		sets *this to incoming node data
*
*	Entry:
*		None.
*
*	Exit:
*		None.
****************************************************************/
void Node::operator = (const Node& node)
{
	if (this != &node)
	{
		m_next = nullptr;
		m_player = node.m_player;
	}
}