/************************************************************************
Class: Array

Array();
	ctor for array
~Array();
	dtor for array

void Add(int to_add);
	adds stuff to array
bool Holds(int check);
	checks to see if check is in array
void Display(ostream & o);
	displays everything in array
*************************************************************************/
#ifndef ARRAY_H
#define ARRAY_H
#include "Container.h"

class Array : public Container
{
public:
	Array();
	~Array();

	void Add(int to_add);
	bool Holds(int check);
	void Display(ostream & o);

protected:
	int * m_array;
	int m_size; 
};
#endif