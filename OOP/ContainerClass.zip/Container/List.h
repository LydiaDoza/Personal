/************************************************************************
 Class: List

 List();
	ctor for List

 ~List();
	dtor for List
 
 void Add(int data);
	adds data to list

 bool Holds(int data);
	checks to see if data is in list 

 void Display(ostream &o);
	displays all stuff in list
*************************************************************************/
#ifndef LIST_H
#define LIST_H
#include "Container.h"
#include "Node.h"

class List : public Container
{
public:
	List();
	~List();

	void Add(int data);
	bool Holds(int data);

	void Display(ostream &o);

private:
	Node * m_head;
	int m_nodes;	
};

#endif