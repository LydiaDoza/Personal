/************************************************************************
Class: Node

Node();
	ctor for Node
Node(int num);
	1 arg ctor for Node
~Node();
	dtor for node
void operator = (const Node & node);
	op equals for Node, sets this node to that node
void SetNext(Node * next);
	set m_next to next
Node * GetNext();
	returns m_next
void SetNum(int num);
	sets m_num to num
int GetNum();
	returns m_num
*************************************************************************/
#ifndef NODE_H
#define NODE_H

class Node
{
public:
	Node();
	Node(int num);
	~Node();
	void operator = (const Node & node);

	void SetNext(Node * next);
	Node * GetNext();

	void SetNum(int num);
	int GetNum();


private:
	Node * m_next;
	int m_num;
};

#endif