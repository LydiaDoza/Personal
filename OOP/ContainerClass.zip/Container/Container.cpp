/******************************************************
*	Author:			Lydia Doza
*	Date created:	2/23/2015
*	Date modified:	2/23/2015
*	Title:			Container.cpp
******************************************************/
#include "Container.h"

/**************************************************************
*	Name:
*		Container()
*
*	Purpose:
*		Sets m_desc to '\0'
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
Container::Container() : m_desc('\0')
{

}

/**************************************************************
*	Name:
*		Container(const char * const name)
*
*	Purpose:
*		sets m_desc to name.
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
Container::Container(const char * const name ) : m_desc(name)
{

}

/**************************************************************
*	Name:
*		~Container
*
*	Purpose:
*		destroys container
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
Container::~Container()
{

}

/**************************************************************
*	Name:
*		operator<<(ostream & o, Conatiner & c)
*
*	Purpose:
*		overloads << operator to print out Container objects
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
ostream & operator<<(ostream & o, Container & c)
{
	o << c.m_desc << endl;
	c.Display(o);

	return o;
}