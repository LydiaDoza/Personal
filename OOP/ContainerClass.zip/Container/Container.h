/************************************************************************
 Class: Container
 
 friend ostream& operator << (ostream & o, Container & c);
	overloads << operator to print Container objects

 Container();
	default ctor for Container

 Container(const char * const name);
	one arg ctor for Container 
 
 virtual ~Container();
	dtor for Container

 virtual void Display(ostream & o) = 0;
	Displays stuff for conatiner

 virtual void Add(int thing) = 0;
	Adds stuff into container

 virtual bool Holds(int stuff) = 0;
	Checks to see if stuff is in container
*************************************************************************/
#ifndef CONTAINER_H
#define CONTAINER_H
#include <iostream>
using std::ostream;
using std::cin;
using std::cout;
using std::endl;

class Container
{
	friend ostream& operator << (ostream & o, Container & c);

public:
	Container();
	Container(const char * const name);
	virtual ~Container();

	virtual void Display(ostream & o) = 0;

	virtual void Add(int thing) = 0;
	virtual bool Holds(int stuff) = 0;

protected:
	const char* const m_desc;
};
#endif