/******************************************************
*	Author:			Lydia Doza
*	Date created:	2/23/2015
*	Date modified:	2/23/2015
*	Title:			List.cpp
******************************************************/
#include "List.h"

/**************************************************************
*	Name:
*		List()
*
*	Purpose:
*		CTOR
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
List::List() : Container("Linked List"), m_head(nullptr), m_nodes(0)
{

}

/**************************************************************
*	Name:
*		~List()
*
*	Purpose:
*		DTOR
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
List::~List()
{
	Node * travel = m_head;
	Node * trail = travel;
	while (travel != nullptr)
	{
		travel = travel->GetNext();
		delete trail;
		trail = travel;
	}

	m_head = nullptr;
	m_nodes = 0;
}

/**************************************************************
*	Name:
*		Add(int data)
*
*	Purpose:
*		Adds data to list IN ORDER from smallest to largest
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
void List::Add(int data)
{
	Node * new_node = new Node;
	Node * travel = m_head;
	Node * trail = nullptr;

	new_node->SetNum(data);

	// if list is empty
	if (m_head == nullptr)
	{
		m_head = new_node;
		new_node->SetNext(nullptr);
	}
	//insert node before head
	else if (new_node->GetNum() <= m_head->GetNum())
	{
		new_node->SetNext(m_head);
		m_head = new_node;
	}

	else
	{
		// While within the list and travel pointer number is less than new node number
		while (travel != nullptr && travel->GetNum() < new_node->GetNum())
		{
			trail = travel;
			travel = travel->GetNext();
		}


		//set trail's next to new_node
		trail->SetNext(new_node);
		
		//new node's next is set to travel
		new_node->SetNext(travel);
	}

	++m_nodes;
}

/**************************************************************
*	Name:
*		Holds(int check)
*
*	Purpose:
*		checks to see if check is in list.
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
bool List::Holds(int check)
{
	bool hold = false;
	Node * travel = m_head;

	while (hold == false && travel != nullptr)
	{
		if (check == travel->GetNum())
			hold = true;

		travel = travel->GetNext();
	}

	return hold;
}

/**************************************************************
*	Name:
*		Display(ostream & o)
*
*	Purpose:
*		Displays all data in List
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
void List::Display(ostream & o)
{
	// Linked list display function
	Node * travel = m_head;

	while (travel != nullptr)
	{
		o << travel->GetNum() << endl;
		travel = travel->GetNext();
	}
}