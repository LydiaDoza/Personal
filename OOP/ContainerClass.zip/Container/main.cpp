#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#include <iostream>
using std::cout;
using std::endl;
#include "Container.h"
#include "Node.h"
#include "List.h"
#include "Array.h"

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	Container* ptr[] = { (new Array), (new List) };

	const int size = sizeof(ptr) / sizeof(*ptr);
	for (int i = 0; i < size; ++i)
	{
		const int limit = 3;
		for (int j = 0; j < limit; ++j)
			ptr[i]->Add(j * 2);

		cout << *ptr[i];

		for (int k = 0; k < limit * 2; ++k)
		{
			cout << k << " is " << (ptr[i]->Holds(k) ? "present\n" :
				"not present\n");
		}

		delete ptr[i];

		cout << "\t========= THE END  ==========" << endl;
	}
	return 0;
}
