/******************************************************
*	Author:			Lydia Doza
*	Date created:	2/23/2015
*	Date modified:	2/23/2015
*	Title:			Node.cpp
******************************************************/
#include "Node.h"

/**************************************************************
*	Name:
*		Node()
*
*	Purpose:
*		ctor for Node, sets m_num to 0 and m_next to nullptr
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
Node::Node() : m_num(0), m_next(nullptr)
{

}

/**************************************************************
*	Name:
*		Node (int num)
*
*	Purpose:
*		sets m_num to num and m_next to nullptr
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
Node::Node(int num) : m_num(num), m_next(nullptr)
{

}

/**************************************************************
*	Name:
*		~Node
*
*	Purpose:
*		Not much since nothing was dynamically allocated
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
Node::~Node()
{

}

/**************************************************************
*	Name:
*		operator=(const Node * node)
*
*	Purpose:
*		sets this node to that node
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
void Node::operator = (const Node & node)
{
	if (this != &node)
	{
		m_num = node.m_num;
	}
}

/**************************************************************
*	Name:
*		SetNext(Node * next)
*
*	Purpose:
*		sets m_next to next
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
void Node::SetNext(Node * next)
{
	m_next = next;
}

/**************************************************************
*	Name:
*		GetNext()
*
*	Purpose:
*		returns m_next
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
Node * Node::GetNext()
{
	return m_next;
}

/**************************************************************
*	Name:
*		SetNum(int num)
*
*	Purpose:
*		Sets m_num to num.
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
void Node::SetNum(int num)
{
	m_num = num;
}

/**************************************************************
*	Name:
*		GetNum()
*
*	Purpose:
*		returns m_num
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
int Node::GetNum()
{
	return m_num;
}