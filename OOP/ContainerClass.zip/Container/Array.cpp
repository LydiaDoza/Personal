/******************************************************
*	Author:			Lydia Doza
*	Date created:	2/23/2015
*	Date modified:	2/23/2015
*	Title:			Array.cpp
******************************************************/
#include "Array.h"

/**************************************************************
*	Name:
*		Array()
*
*	Purpose:
*		Array ctor. sets m_array to nullptr, m_size to 0, and
*		m_desc to "array"
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
Array::Array() : m_array(nullptr), m_size(0), Container("Array")
{
	
}

/**************************************************************
*	Name:
*		~Array()
*
*	Purpose:
*		Array
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
Array::~Array()
{
	delete[] m_array;
	m_array = nullptr;
	m_size = 0;
}


/**************************************************************
*	Name:
*		Add(int to_add)
*
*	Purpose:
*		adds to_add to array
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
void Array::Add(int to_add)
{
	int * temp = new int[m_size + 1];

	for (int i = 0; i < m_size; i++)
		temp[i] = m_array[i];

	temp[m_size] = to_add;

	delete[] m_array;
	m_array = temp;
	
	++m_size;
}

/**************************************************************
*	Name:
*		Hold(int check)
*
*	Purpose:
*		checks if check is in array
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
bool Array::Holds(int check)
{
	bool hold = false;

	for (int i(0); i < m_size; i++)
	{
		if (check == m_array[i])
			hold = true;
	}

	return hold;
}

/**************************************************************
*	Name:
*		Display(ostream & o)
*
*	Purpose:
*		Displays all stuff in array
*
*	Entry:
*		nothing.
*
*	Exit:
*		nothing.
****************************************************************/
void Array::Display(ostream & o)
{
	// array display function
	for (int i = 0; i < m_size; ++i)
		o << m_array[i] << endl;
}