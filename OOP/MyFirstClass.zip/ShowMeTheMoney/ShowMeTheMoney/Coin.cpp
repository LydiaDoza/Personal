#include "Coin.h"
#include <iostream>
using std::cout;
using std::cin;
using std::endl;

//void InitializeCoins(COIN coins[])
//{
//	// {denom, count, single, multiple
//	coins[0] = { 25, 0, "quarter", "quarters" };
//	coins[1] = { 10, 0, "dime", "dimes" };
//	coins[2] = { 5, 0, "nickel", "nickels" };
//	coins[3] = { 1, 0, "penny", "pennies" };
//}
Coin::Coin(int denom, long count, char * single, char * multiple) :m_denom(denom), m_count(count)
{
	m_single = new char[strlen(single) + 1];
	strcpy(m_single, single);

	m_multiple = new char[strlen(multiple) + 1];
	strcpy(m_multiple, multiple);
}
Coin::~Coin()
{

	delete[] m_single;
	m_single = nullptr;

	delete[] m_multiple;
	m_multiple = nullptr;
}

void Coin::Change(long userMoney, Coin coins[])
{
	for (int i(0); i < 4; i++)	// 4 is the number of types of coins
		while (userMoney >= coins[i].m_denom 
			&& userMoney > 0)
		{
			userMoney = userMoney - coins[i].m_denom;
			coins[i].m_count++;
		}
}

void Coin::Print(Coin coins[])
{
	cout << "The amount of money you entered equals: " << endl;
	for (int i = 0; i < 4; i++)
	{
		if (m_count > 0)
		{
			if (m_count == 1)
			{
				cout << m_count << ' '
					<< coins[i].m_single << endl;
			}
			else
				cout << coins[i].m_count << ' '
				<< coins[i].m_multiple << endl;
		}
	}

	cout << endl;
}