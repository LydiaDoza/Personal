

#ifndef COIN_H
#define COIN_H

class Coin
{
public:
	Coin(int denom, long count, char * single, char * multiple);
	~Coin();
	void Print(Coin coins[]);
	void Change(long userMoney, Coin coins[]);

private:
	int m_denom;				// 1 or 5 or 10 or 25
	long m_count;				// Occurrence count
	char* m_single;				// Text for ONE (1) occurrence (ie, "penny")
	char* m_multiple;			// Text for MORE THAN ONE occurrence (ie, "pennies")
};

#endif