/***********************************************************
* Author:					Lydia Doza
* Date Created:				1/8/2014
* Last Modification Date:	2/2/2014
* Lab Number:				CST 136 Lab 1
* Filename:					LabHW1.cpp
*
* Overview:
*	This program calculates the minimum number of quarters,
*	nickels, dimes, nickels, and penniers that are contained
*	in a given amount of money.
*
* Input:
*	A dollar amount from the user is input.
*	IE:	145  (for $1.45)
*
* Output:
*	The number of each coin in the given dollar amount is
*	printed to the screen.
*	IE:		The amount of money you entered equals:
*			5 quarters
*			2 dimes
************************************************************/
#include "Coin.h"
#include <iostream>
using std::cout;
using std::cin;
using std::endl;

#define _CRTDBG_MAP_ALLOC

struct COIN
{
	int denom;				// 1 or 5 or 10 or 25
	long count;				// Occurrence count
	const char* single;		// Text for ONE (1) occurrence (ie, "penny")
	const char* multiple;	// Text for MORE THAN ONE occurrence (ie, "pennies")
};

void InitializeCoins(COIN coins[]);
long PromptUser(long userMoney);
void Change(long userMoney, COIN coins[]);
void Print(COIN coins[]);
long EndProgram(long userMoney);

const int numTypesOfCoins(4);

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	
	//Coin coins[4] = { { 25, 0, "quarter", "quarters" }, { 10, 0, "dime", "dimes" },
		//			{ 5, 0, "nickel", "nickels" }, { 1, 0, "penny", "pennies" } };
	
	COIN totally_coins[4] = { 0 };
	InitializeCoins(totally_coins);
	
	long userMoney(0);

	while (userMoney != -1)
	{
		userMoney = PromptUser(userMoney);

		//coins->Change(userMoney, coins);
		//coins->Print(coins);
		Change(userMoney, totally_coins);
		Print(totally_coins);

		userMoney = EndProgram(userMoney);
	}


	cout << "Have a good day!" << endl;

	return 0;
}

/**************************************************************
*	Purpose:
*		Initiliazes coin values to zero and names the
*		singles and plural
*
*	Entry:
*		nothing from user.
*
*	Exit:
*		coin values and occurrences are defined.
****************************************************************/
void InitializeCoins(COIN coins[])
{
	// {denom, count, single, multiple
	coins[0] = { 25, 0, "quarter", "quarters" };
	coins[1] = { 10, 0, "dime", "dimes" };
	coins[2] = { 5, 0, "nickel", "nickels" };
	coins[3] = { 1, 0, "penny", "pennies" };
}

/**************************************************************
*	Purpose:
*		Prompts user for money amount.
*
*	Entry:
*		userMoney long int, user inputer for amount
*
*	Exit:
*		userMoney amount
****************************************************************/
long PromptUser(long userMoney)
{
	cout << "Please enter an amount of money (for $1.45, input 145): ";
	cin >> userMoney;

	return userMoney;
}

/**************************************************************
*	Purpose:
*		Prompts user for money amount.
*
*	Entry:
*		userMoney long int, user inputer for amount
*
*	Exit:
*		userMoney amount
****************************************************************/
void Change(long userMoney, COIN coins[])
{
	for (int i(0); i < numTypesOfCoins; i++)
		while (userMoney >= coins[i].denom 
			&& userMoney > 0)
		{
			userMoney = userMoney - coins[i].denom;
			coins[i].count++;
		}
}

/**************************************************************
*	Purpose:
*		Prints the results of the number of pennier, nickels,
*		dimes, and quarters.
*
*	Entry:
*		nothing from user, coin array.
*
*	Exit:
*		prints only the coins that have a cont greater than 0
*		to the screen.
****************************************************************/
void Print(COIN coins[])
{
	cout << "The amount of money you entered equals: " << endl;
	for (int i = 0; i < numTypesOfCoins; i++)
	{
		if (coins[i].count > 0)
		{
			if (coins[i].count == 1)
			{
				cout << coins[i].count << ' '
					<< coins[i].single << endl;
			}
			else
				cout << coins[i].count << ' '
				<< coins[i].multiple << endl;
		}
	}
}

/**************************************************************
*	Purpose:
*		Prompts user to end the program
*
*	Entry:
*		-1 to exit, any other number to continue
*
*	Exit:
*		either user is allowed to enter a new dollar amount to
*		calculate the number of quarters, nickels, dimes, and
*		pennies, or the program will end.
****************************************************************/
long EndProgram(long userMoney)
{
	cout << "\nWould you like to exit?\nInput -1 to exit."
		<< "\nInput any other number to enter another amount.";

	cin >> userMoney;
	system("cls");
	return userMoney;
}