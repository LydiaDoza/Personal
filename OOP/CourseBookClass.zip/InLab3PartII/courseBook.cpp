#include "courseBook.h"
#include <fstream>

using std::ifstream;

void courseBook::loadFile(std::string file)
{
	char buffer[100];
	ifstream inFile(file.c_str());

	if (inFile.is_open())
	{
		while (inFile.getline(buffer, 100, '\n'))
		{
			char* name = strtok(buffer, ",");
			char* creditsstr = strtok(0, ",");
			int c = atoi(creditsstr);
			m_courses[m_courseCount] = course(name, c);
			m_courseCount++;
		}
	}
}

course * courseBook::getCourseById(const int & id) 
{
	return &(m_courses[id]);
}

courseBook::courseBook() : m_courseCount(0)
{
}

courseBook::~courseBook()
{

}

int courseBook::numberOfCourses() const
{
	return m_courseCount;
}

void courseBook::setCourseCount(int courseCount)
{
	m_courseCount = courseCount;
}

int courseBook::getCourseCount()
{
	return m_courseCount;
}