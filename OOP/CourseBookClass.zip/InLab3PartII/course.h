#include <string>
#include <vector>
#include "student.h"
#include <iostream>

using std::string;
using std::vector;
using std::cout;
using std::endl;

#ifndef COURSE_H
#define COURSE_H

enum GRADE
{
	A = 4,
	B = 3,
	C = 2,
	D = 1,
	F = 0,
	NOTSET = -1
};

struct entry
{
	student *s;
	GRADE g;
};



class course
{
public:
	course();
	course(string name, int credits);
	~course();

	inline int getCredits() const { return m_credits; }

	void addStudent(student* s);
	void print();
	void setGrade(student *s, GRADE g);
	const char* printGrade(GRADE g);
	string * getNAME();
	void setNAME(string name);
	int getStudentCount() const;
	void setStudentCount(int studentCount);
	void setCredits(int credits);

private:

	int m_studentCount;
	int m_credits;
	string* m_name;

	entry m_students[100];
};

#endif