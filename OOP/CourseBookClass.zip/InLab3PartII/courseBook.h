#include "course.h"

#ifndef COURSEBOOK_H
#define COURSEBOOK_H

const int MAX_COURSES = 50;

class courseBook
{
public:
	courseBook();
	~courseBook();

	void loadFile(string file);
	int numberOfCourses() const;
	course* getCourseById(const int &id);
	void setCourseCount(int courseCount);
	int getCourseCount();

private:
	course m_courses[MAX_COURSES];
	int m_courseCount;
};

#endif
