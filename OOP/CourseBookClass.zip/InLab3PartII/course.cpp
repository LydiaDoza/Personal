#include "course.h"

course::course()
{
	course("", -1);
}

course::course(std::string name, int credits)
{
	m_name = new string(name);
	m_credits = credits;
	m_studentCount = 0;
}

course::~course()
{
	delete m_name;
	m_name = nullptr;
}

void course::addStudent(student* s)
{
	entry e;
	e.s = s;
	e.g = NOTSET;

	m_students[m_studentCount] = e;
	m_studentCount++;
}

void course::print()
{
	cout << *this->m_name << "\nCredits: " << this->m_credits << endl;
	cout << "Student Name  Grade" << endl;
	for(int x = 0; x < m_studentCount; x++)
	{
		cout << m_students[x].s->getName() << " " << printGrade(m_students[x].g) << endl;
	}
}

void course::setGrade(student *s, GRADE g)
{
	for(int x = 0; x < m_studentCount; x++)
	{
		if(m_students[x].s == s)
			m_students[x].g = g;
	}
}

const char* course::printGrade(GRADE g)
{
	switch(g)
	{
	case A:
		return "A";
	case B:
		return "B";
	case C:
		return "C";
	case D:
		return "D";
	case F:
		return "F";
	case NOTSET:
		return "(Not Set)";
	}
}

string * course::getNAME()
{
	return m_name;
}

void course::setNAME(string name)
{
	m_name = new string(name);
}

int course::getStudentCount() const
{
	return m_studentCount;
}
void course::setStudentCount(int studentCount)
{
	m_studentCount = studentCount;
}
void course::setCredits(int credits)
{
	m_credits = credits;
}