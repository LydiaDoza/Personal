#include <string>

using std::string;

#ifndef STUDENT_H
#define STUDENT_H

class student
{
	public:
		student()
		{
			student("");
		}

		student(string name)
		{
			m_name = name;
		}

		const string& getName() const
		{
			return m_name;
		}
		string setName(string name)
		{
			m_name = name;
		}

	private:
		string m_name;
};

#endif