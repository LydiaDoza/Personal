/************************************************************************
* Class: Date
*
* Constructors:
*	Sport()
*		Creates and a sport and sets length and array to zero and
*		nullptr respectively.
*
* Destructors:
*	~Sport()
*		Deallocates memory from array and sport
*
* Public Methods:
*	void DisplayMenu()
*		Displays menu options to console window.
*	void Add()
*		Calls Player ctor and adds pointer to player to array
*	void List()
*		Displays Players in array and attributes to screen
*	void Search() const
*		Prompts user for a name, checks name against the names of
*		existing players in array
*	void DisplayCount() const;
*		Displays number of players.
*	void PromptUser()
*		receives user input from displaymenu()
*************************************************************************/
#ifndef SPORT_H
#define SPORT_H

class Sport
{
public:
	Sport();
	~Sport();
	void DisplayMenu();
	void Add();
	void List();
	void Search() const;
	void DisplayCount() const;
	void PromptUser();

private:

	Player ** m_array;
	int m_length;
};

#endif