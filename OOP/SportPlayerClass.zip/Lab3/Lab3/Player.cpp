/******************************************************
*	Author:			Lydia Doza
*	Date created:	1/25/2015
*	Date modified:	1/25/2015
*	Title:			Player.cpp
******************************************************/
#include "Player.h"
#include <iostream>
using std::cout;
using std::cin;
using std::endl;

#include <iomanip>
using std::setw;
using std::setprecision;
using std::fixed;
using std::left;


/**************************************************************
*	Name:
*		Player()
*
*	Purpose:
*		sets m_grade to 13, m_gpa to 4.0, and m_name to null.
*
*	Entry:
*		Nothing.
*
*	Exit:
*		members are initialized.
****************************************************************/
Player::Player() : m_grade(13), m_gpa(4.0)
{
	m_name = new char[64];
	m_name[64] = { '\0' };
}

/**************************************************************
*	Name:
*		Player(name, grade, gpa)
*
*	Purpose:
*		creates new player and assigns name to m_name, grade
*		to m_grade, and gpa to m_gpa
*
*	Entry:
*		name, grade, and gpa
*
*	Exit:
*		Player initialized.
****************************************************************/
Player::Player(char * name, int grade, double gpa) : m_grade(grade), m_gpa(gpa)
{
	m_name = new char[strlen(name) + 1];
	strcpy(m_name, name);
}

/**************************************************************
*	Name:
*		~Player()
*
*	Purpose:
*		deallocates memory from player and reinitializes m_name
*
*	Entry:
*		nothing.
*
*	Exit:
*		memory freed and m_name set to nullptr
****************************************************************/
Player::~Player()
{
	delete[] m_name;
	m_name = nullptr;
}

/**************************************************************
*	Name:
*		Display()
*
*	Purpose:
*		Displays player properties
*
*	Entry
*		Nothing
*
*	Exit:
*		player propteries displayed
****************************************************************/
void Player::Display() const
{
	cout << '\n' << setw(15) << left << m_name
		<< setw(4)  << m_grade 
		<< setw(7) << setprecision(3) << m_gpa << "\n" << endl;
}

/**************************************************************
*	Name:
*		Search(name)
*
*	Purpose:
*		checks m_name against name
*
*	Entry:
*		name
*
*	Exit:
*		true or false, true if the same, false if not
****************************************************************/
bool Player::Search(const char* name)const
{
	bool check = false;

	if (!strcmp(name, m_name)) // If the strcmp returns a zero, then true
		check = true;

	return check;
}