/************************************************************************
* Class: Player
*
* Constructors:
*	Player()
*		Creates and sets month, day, year to 10/1/2014
*
* Destructors:
*	~Player()
*		Deallocates m_month, m_day, m_year
*
* Public Methods:
*	void Set( int month, int day, int year )
*		Sets date to user input. If no input, date is set to 10/1/2014
*	void Increment()
*		Increments day (month and year if necessary)
*	voit Display()
*		Display date as MM/DD/YYYY format.
*************************************************************************/
#ifndef PLAYER_H
#define PLAYER_H

class Player
{
public:
	Player();
	Player(char * name, int grade, double gpa);
	~Player();
	bool Search(const char*) const;
	void Display() const;

private:
	char * m_name;
	int m_grade;
	double m_gpa;
};

#endif