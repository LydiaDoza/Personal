/******************************************************
*	Author:			Lydia Doza
*	Date created:	1/25/2015
*	Date modified:	1/25/2015
*	Title:			Sport.cpp
******************************************************/
#include "Player.h"
#include "Sport.h"

#include <iostream>
using std::cout;
using std::cin;
using std::endl;


/**************************************************************
*	Name:
*		Sport()
*
*	Purpose:
*		sets m_array to nullptr and length to zero
*
*	Entry:
*		Nothing.
*
*	Exit:
*		initialized m_array and m_length
****************************************************************/
Sport::Sport() : m_array(nullptr), m_length(0)
{

}

/**************************************************************
*	Name:
*		~Sport()
*
*	Purpose:
*		deallocates m_array and elements of m_array
*
*	Entry:
*		Nothing.
*
*	Exit:
*		Memory is deallocated.
****************************************************************/
Sport::~Sport()
{
	for (int i = 0; i < m_length; i++)
	{
		delete m_array[i];
	}

	delete[] m_array;
}

/**************************************************************
*	Name:
*		DisplayMenu()
*
*	Purpose:
*		Displays menu
*
*	Entry:
*		Nothing.
*
*	Exit:
*		calls prompt user
****************************************************************/
void Sport::DisplayMenu()
{
	cout << "Oregon Institute of Technology" << endl;
	cout << "\tA - Add a Player"
		<< "\n\tS - Search For / Display a Player"
		<< "\n\tD - Display all Players"
		<< "\n\tC - Display Current Count of Players"
		<< "\n\tE - Exit" << endl;
}

/**************************************************************
*	Name:
*		Add()
*
*	Purpose:
*		dynamically creates a new player and adds it to array
*
*	Entry:
*		None.
*
*	Exit:
*		New player is added, array grows by one.
****************************************************************/
void Sport::Add()
{
	Player ** temp = new Player *[m_length + 1];
	char name[64] = { '\0' };
	int grade(0);
	double gpa(0.0);

	for (int i(0); i < m_length; i++)
	{
		temp[i] = m_array[i];
	}

	cout << "What is the new player's name?" << endl;
	cin >> name;

	cout << "What is the player's grade?" << endl;
	cin >> grade;

	cout << "What is the player's gpa?" << endl;
	cin >> gpa;

	temp[m_length] = new Player(name, grade, gpa);

	delete[] m_array;

	m_array = temp;

	++m_length;
}

/**************************************************************
*	Name:
*		List()
*
*	Purpose:
*		Displays all players in sport
*
*	Entry:
*		Nothing.
*
*	Exit:
*		All players displayed to screen.
****************************************************************/
void Sport::List()
{
	for (int i(0); i < m_length; i++)
	{
		m_array[i]->Display();
	}
}

/**************************************************************
*	Name:
*		Search()
*
*	Purpose:
*		Searches through players list, if found, prints player
*		info to screen
*
*	Entry:
*		name to compare
*
*	Exit:
*		either nothing or player and it's info
****************************************************************/
void Sport::Search() const
{
	char name[64] = { '\0' };
	bool found = false;
	int flag = 0;

	cout << "Who would you like to find? ";
	cin >> name;

	for (int i(0); i < m_length; i++)
	{
		if (m_array[i]->Search(name))
		{
			flag = i;
			found = true;
		}
	}

	if (found)
		m_array[flag]->Display();
	else
		cout << "\nPlayer not found." << endl;
}

/**************************************************************
*	Name:
*		DisplayCount()
*
*	Purpose:
*		returns number of players
*
*	Entry:
*		nothing.
*
*	Exit:
*		number of players printed to screen.
****************************************************************/
void Sport::DisplayCount() const
{
	cout << '\n' << m_length << endl;
}

/**************************************************************
*	Name:
*		PromptUser()
*
*	Purpose:
*		calls appropriate function given user input
*
*	Entry:
*		user input based on menu in DisplayMenu()
*
*	Exit:
*		method called.
****************************************************************/
void Sport::PromptUser()
{
	char choice = '\0';
	char temp[128] = { '\0' };

	while (choice != 'E')
	{
		DisplayMenu();
		cin.sync();
		cin.getline(temp, 128);
		choice = temp[0];
		choice = toupper(choice);

		if (choice != 'A' && choice != 'S'
			&& choice != 'D' && choice != 'C'
			&& choice != 'E')
		{
			cout << "\nYour choice did not match with the options, "
				<< "please choose from the options." << endl;
		}
		else
		{
			switch (choice)
			{
			case 'A':
				Add();
				break;

			case 'S':
				Search();
				break;

			case 'D':
				List();
				break;

			case 'C':
				DisplayCount();
				break;

			case 'E':
				break;
			default:
				cout << "\nYour choice did not match with the options." << endl;

				break;
			}

		}
	}

}