/***********************************************************
* Author:					Lydia Doza
* Date Created:				3/11/2015
* Last Modification Date:	3/12/2015
* Lab Number:				CST 136 Lab 9
* Filename:					Templates
*
* Overview:
*	Practicing with templates and stuff
*
* Input:
*	
*
* Output:
*	the list is printed.
************************************************************/
#include "List.h"

int main()
{
	List <int> myList;
	myList.AddNode(5);
	myList.AddNode(12);
	myList.AddNode(56);
	myList.Display();

	List <double> myListD;
	myListD.AddNode(12.3);
	myListD.AddNode(24.6);
	myListD.AddNode(87.123);
	myListD.AddNode(8.584);
	myListD.Display();

	List <float> myListF;
	myListF.AddNode(1.2F);
	myListF.AddNode(3.1F);
	myListF.AddNode(4.7F);
	myListF.Display();

	List <int> empty;

	try
	{
		myList.DeleteNode(12);

	}
	catch (char* err)
	{
		cout << '\n' << err << endl;
	}
}
