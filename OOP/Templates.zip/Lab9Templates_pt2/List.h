#ifndef LIST_H
#define LIST_H

#include "Node.h"

template <typename T>
class List
{
public:
	List();
	~List();

	void AddNode(T data);
	void DeleteNode(T data);
	void Display();

private:
	Node<T> * m_head;
};


template <typename T>
List<T>::List() : m_head(nullptr)
{

}

template <typename T>
List<T>::~List()
{
	Node<T>* travel = m_head;
	Node<T>* trail = m_head;

	while (travel != nullptr)
	{
		trail = travel;
		travel = travel->GetNext();
		delete trail;
	}
}

template <typename T>
void List<T>::AddNode(T data)
{
	Node<T>* travel = m_head;
	Node<T>* new_node = new Node < T > ;

	// set new node to data
	new_node->SetData(data);

	//if list is empty
	if (m_head == nullptr)
	{
		m_head = new_node;
		new_node->SetNext(nullptr);
	}
	//append node to end of list
	else
	{
		while (travel->GetNext() != nullptr)
		{
			travel = travel->GetNext();
			//set travel to next
		}

		//set travel's next to new node
		travel->SetNext(new_node);
		new_node->SetNext(nullptr);
	}
}

template <typename T>
void List<T>::DeleteNode(T data)
{
	bool found = false;
	Node<T>* travel = m_head;
	Node<T>* trail = m_head;

	if (m_head == nullptr) throw "\nList is Empty.";

	while (travel != nullptr && !found)
	{
		// if found, then delete
		if (travel->GetData() == data)
		{
			// toggle found
			found = true;

			// move pointers, delete desired pointer
			trail = travel;
			travel = travel->GetNext();
			delete trail;
		}
		else
		{
			trail = travel;
			travel = travel->GetNext();
		}
	}

	// after the loops have been gone through
	// if still not found
	if (!found) throw "\nItem not found.";
}

/***************************************************************
*	Name:
*		Display()
*
*	Purpose:
*		Displays all nodes in list
*
*	Entry:
*		None.
*
*	Exit:
*		Number of nodes is returned.
****************************************************************/
template <typename T>
void List<T>::Display()
{
	Node<T>* travel = m_head;

	cout << endl;

	while (travel != nullptr)
	{
		// display this node.
		travel->Display();

		cout << " ";

		//get next node
		travel = travel->GetNext();
	}

}
#endif