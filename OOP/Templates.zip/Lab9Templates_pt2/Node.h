#ifndef NODE_H
#define NODE_H

#include <iostream>
using std::cout;
using std::endl;

template <typename T>
class Node 
{
public:
	Node();
	~Node();
	
	void SetNext(Node<T> * next);
	Node<T> * GetNext();

	void SetData(T data);
	T GetData() const;

	void Display();

private:
	Node<T> * m_next;
	T m_data;
};

template <typename T>
Node<T>::Node() : m_next(nullptr), m_data()
{

}

template <typename T>
Node<T>::~Node()
{
	m_next = nullptr;
}

template <typename T>
void Node<T>::SetNext(Node<T> * next)
{
	m_next = next;
}

template <typename T>
Node<T> * Node<T>::GetNext()
{
	return m_next;
}


template <typename T>
void Node<T>::SetData(T data)
{
	m_data = data;
}

template <typename T>
T Node<T>::GetData() const
{
	return m_data;
}

template <typename T>
void Node<T>::Display()
{
	cout << m_data;
}
#endif