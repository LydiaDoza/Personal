/***********************************************************
* Author:					Lydia Doza
* Date Created:				3/12/2015
* Last Modification Date:	3/12/2015
* Lab Number:				CST 136 Lab 9
* Filename:					Lab9Templates_pt1
*
* Overview:
*	Practice templates and exceptions
*
* Input:
*	nothing
*
* Output:
*	stuff is printed to screen
************************************************************/
#include "SafeArray.h"

int main()
{
	SafeArray <int, 5> iArray; 		// integer array � size of 10
	SafeArray <double>  dblArray;	// double array � default size
	SafeArray < >  defArray;		// default to int � size defaults too

	int x;
	cout << "\n\nMy int array: ";
	for (x = 0; x < 5; x++)
	{
		iArray[x] = x;
	}

	for (x = 0; x < 5; x++)
	{
		cout << iArray[x] << "  ";
	}

	cout << "\n\nMy double array:  ";
	for (x = 0; x < 10; x++)
	{
		dblArray[x] = x + 100;
	}

	for (x = 0; x < 10; x++) 		// oops � make sure you handle this properly in your class!
	{
		cout << dblArray[x] << "  ";
	}

	cout << "\n\nMy default array:   ";
	for (int x = 0; x < 10; x++)
	{
		defArray[x] = x * x + 1;
	}

	try
	{
		for (int x = 0; x <= 10; x++)
		{
			cout << defArray[x] << "  ";
		}
	}
	catch (char* str)
	{
		cout << str;
	}
	cout << endl;
}