/************************************************************************
* Class: SafeArray
*
* Constructors:
*	SafeArray()
*		dynamically allocates mem for m_array
*
* Destructors:
*	~SafeArray()
*		deletes the dynamically allocated memory
*
* Public Methods:
*	operator[](int index)
*		
*************************************************************************/
#ifndef SAFEARRAY_H
#define SAFEARRAY_H

#include <iostream>
using std::cout;
using std::cin;
using std::endl;

template < typename T = int, int size = 10>
class SafeArray
{
public:
	SafeArray();
	~SafeArray();
	T & operator[](int index);

private:
	T * m_array;
};

/**************************************************************
*	Name:
*		SafeArray()
*
*	Purpose:
*		Sets m_aray to nullptr, then dynamically allocates the
*		array of type T with size size
*
*	Entry:
*		None.
*
*	Exit:
*		None.
****************************************************************/
template <typename T, int size>
SafeArray<T, size>::SafeArray() : m_array(nullptr)
{
	m_array = new T[size];

}

/**************************************************************
*	Name:
*		~SafeArray()
*
*	Purpose:
*		deletes m_array then sets it to nullptr
*
*	Entry:
*		None.
*
*	Exit:
*		None.
****************************************************************/
template <typename T, int size>
SafeArray<T, size>::~SafeArray()
{
	delete[] m_array;
	m_array = nullptr;
}

/**************************************************************
*	Name:
*		operator[]()
*
*	Purpose:
*		overloads [] such that an exception is thrown if index
*		is out of bounds.
*
*	Entry:
*		None.
*
*	Exit:
*		None.
****************************************************************/
template <typename T, int size>
T& SafeArray<T, size>::operator[](int index)
{
	// index is out of bounds
	if (index >= size || index < 0) throw "\nindex out of bounds";

	return m_array[index];
}
#endif