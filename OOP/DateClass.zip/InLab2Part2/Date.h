/************************************************************************
* Class: Date
*
* Constructors:
*	Date()
*		Creates and sets month, day, year to 10/1/2014
*
* Destructors:
*	~Date()
*		Deallocates m_month, m_day, m_year
*
* Public Methods:
*	void Set( int month, int day, int year )
*		Sets date to user input. If no input, date is set to 10/1/2014
*	void Increment()
*		Increments day (month and year if necessary)
*	voit Display()
*		Display date as MM/DD/YYYY format.
*************************************************************************/
#ifndef DATE_H
#define DATE_H

const int daysArraySize = 12;
const int daysArray[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

class Date
{
private:
	int m_month;
	int m_day;
	int m_year;

public:
	Date();
	~Date();

	void Set(int month = 10, int day = 1, int year = 2014);
	void Increment();
	void Display();
};

#endif