/***********************************************************
* Author:					Lydia Doza
* Date Created:				1/24/2015
* Last Modification Date:	1/25/2015
* Lab Number:				CST 136 In-Lab 2 Part 3
* Filename:					Main.cpp
*
* Overview:
*	This program tests the Date class. It creates a date and
*	increments it one day at a time (and a month and/or a year
*	if necessary).
*
* Input:
*	
*
* Output:
*	
*
************************************************************/
#include <iostream>
#include "Date.h"
using std::cout;
using std::cin;
using std::endl;

int main()
{
	Date today;
	today.Set(10, 7, 2014);

	for (int i = 0; i < 370; i++)
	{
		today.Increment();
		today.Display();
	}

	cout << "\nEnd of First Part." << endl;
	today.Set(6);
	
	for (int i(0); i < 16; i++)
	{
		today.Increment();
		today.Display();
	}

	cout << "\nEnd of Second Part." << endl;
	today.Set();
	for (int i = 0; i < 10; i++)
	{
		today.Display();
		today.Increment();
	}

	return 0;
}