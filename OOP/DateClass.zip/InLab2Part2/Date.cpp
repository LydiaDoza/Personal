/******************************************************
*	Author:			Lydia Doza
*	Date created:	1/24/2015
*	Date modified:	1/24/2015
*	Title:			Date.cpp
******************************************************/
#include "Date.h"
#include <iostream>
using std::cout;
using std::cin;
using std::endl;

/**************************************************************
*	Name:
*		Date()
*
*	Purpose:
*		Overwritten default constructor. Sets month to October
*		(10), day to 1, and year to 2014.
*
*	Entry:
*		Nothing.
*
*	Exit:
*		All objects in book class changed. Month to 10, day to
*		1, and year to 2014.
****************************************************************/
Date::Date() : m_month(10), m_day(1), m_year(2014)
{

}

/**************************************************************
*	Name:
*		~Date()
*
*	Purpose:
*		Deallocates resources. Resets members to initial
*		values.
*
*	Entry:
*		Nothing.
*
*	Exit:
*		All objects reset.
****************************************************************/
Date::~Date()
{

}


/**************************************************************
*	Name:
*		Set()
*
*	Purpose:
*		Default sets date, month to 10, day to 1, and year to
*		2014. Allows user to set month, day, and year in that
*		order.
*
*	Entry:
*		nothing, or month, or month and day, or month day and
*		year.
*
*	Exit:
*		Date is set.
****************************************************************/
void Date::Set(int month, int day, int year)
{
	m_month = month;
	m_day = day;
	m_year = year;
}

/**************************************************************
*	Name:
*		Increment()
*
*	Purpose:
*		Increments day. Increments month if necessary.
*		Increments year if necessary.
*
*	Entry:
*		Nothing.
*
*	Exit:
*		Date is incremented.
****************************************************************/
void Date::Increment()
{
	if (m_day + 1 > daysArray[m_month - 1])
	{
		m_day = 1;
		if (m_month + 1 > daysArraySize)
		{
			m_month = 1;
			++m_year;
		}
		else
			++m_month;
	}
	else
		++m_day;
}

/**************************************************************
*	Name:
*		Display()
*
*	Purpose:
*		Displays date.
*
*	Entry:
*		Nothing.
*
*	Exit:
*		Date is displayed to screen.
****************************************************************/
void Date::Display()
{
	if (m_day + 1 > daysArray[m_month - 1])
	{

		cout << m_month << '/'
			<< m_day << '/'
			<< m_year << endl;
		cout << "\n";
		system("pause");
	}
	else
	{
		cout << m_month << '/'
			<< m_day << '/'
			<< m_year << endl;
	}
}